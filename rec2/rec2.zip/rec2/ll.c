#include <stdlib.h>

#include "ll.h"

// struct node
// {
// 	int val;
// 	struct node *next;
// };


struct node* add_two_num (struct node* l1, struct node* l2)
{
	/*
	 * FIX ME:
	 */
	return NULL;
}


