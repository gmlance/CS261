/* CS 261 Recitation 3: Anagram Detector
 */

#include <stdio.h>
#include <string.h>

void sort(char* str) {

  int n = strlen(str);

  for (int i = 0; i < n - 1; i++) {
    for (int j = 0; j < n - i - 1; j++) {
      if (str[j] > str[j+1]) {
        char swap = str[j+1];
        str[j+1] = str[j];
        str[j] = swap;
      }
    }
  }
}
/*
  The Function checks two given strings (a, b) and return
  1 if they are anagram, and 0 otherwise
  Assuming:
  1. a and b are of the same length
  2. a and b are made up of symbols from the set of 26 lowercase characters
 */

int check_anagram(char *a, char *b)
{
  //have to copy it into somewhere else first
  char a_arr[1000];
  char b_arr[1000];
  strcpy(a_arr, a);
  strcpy(b_arr, b);

  //sort both
  sort(a_arr);
  sort(b_arr);

  //compare the two sorted ones
  if (strcmp(a_arr, b_arr) == 0) {
    return 1;
  }
  else {
    return 0;
  }
}


int main()
{
  
  printf("Test 1.....\n");
  printf("\"heart\", \"earth\"\n");
  printf("Expected: 1 \n");
  printf("Acutal: %d\n\n", check_anagram("heart", "earth"));


  printf("Test 2.....\n");
  printf("\"python\", \"typhon\"\n");
  printf("Expected: 1 \n");
  printf("Acutal: %d\n\n", check_anagram("python", "typhon"));

  printf("Test 3.....\n");
  printf("\"race\", \"care\"\n");
  printf("Expected: 1 \n");
  printf("Acutal: %d\n\n", check_anagram("race", "care"));

  printf("Test 4.....\n");
  printf("\"listen\", \"silent\"\n");
  printf("Expected: 1 \n");
  printf("Acutal: %d\n\n", check_anagram("listen", "silent"));

  printf("Test 5.....\n");
  printf("\"seal\", \"leaf\"\n");
  printf("Expected: 0 \n");
  printf("Acutal: %d\n\n", check_anagram("seal", "leaf"));

  printf("Test 6.....\n");
  printf("\"asdfghjkl\", \"aasdfghjk\"\n");
  printf("Expected: 0 \n");
  printf("Acutal: %d\n\n", check_anagram("asdfghjkl", "aasdfghjk"));

  

  return 0;
}

